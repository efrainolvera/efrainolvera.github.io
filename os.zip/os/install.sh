#!/bin/bash/
unzip -n files.zip ~/
cd . ~/