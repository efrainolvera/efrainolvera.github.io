#!/bin/bash
#
# VARIABLES
#
PWD=$(pwd)
source ${PWD}/Colors.sh
#
# CÓDIGO
#
sleep 0.1
clear
Termux
echo -e -n "${verde}
┌═══════════════════════════════════════┐
█ [${blanco}01${verde}] ┃ ${blanco}nmap                 ${verde}┃ ${blanco}
${verde}█
█═══════════════════════════════════════█

              ┌═════════════┐           ┃
┌══════════<<<█ [${blanco}00${verde}] ┃ ${rojo}EXIT ${verde}█<<<════════┘
┃             └═════════════┘
┃
└═>>> "${blanco}
read -r TOOL

if [[ $TOOL == 0 || $TOOL == 00 ]]; then
exit
elif [[ $TOOL == 1 || $TOOL == 01 ]]; then
cd .
sh a.sh ~/

else
echo -e "${rojo}
┌═════════════════════┐
█ ${blanco}¡OPCIÓN INCORRECTA! ${rojo}█
└═════════════════════┘
"${blanco}
sleep 1
fi